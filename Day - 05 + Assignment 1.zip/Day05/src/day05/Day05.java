/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package day05;

/**
 *
 * @author macstudent
 */
public class Day05 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    
//        short a = 10;
//        short b = 20;
//        short c = a;
//        
//        short d = (short) (a*b);
//    
//        int a=23, b=5;
//        
//        double c = ((double)a/(double)b);
//        
//        
//        
//        char ch = 65;
//        
//        int ch1 = 'B';
//        
//        String s1 = "Hello";
//        String s2 = " Hello".trim();
//        
//        if(s1 == s2){
//        
//            System.out.println("Ok");
//            
//        }
//        else{System.out.println("No");}
//        
//        System.out.println("Value Is : " + ch1);
//
//
//        
//        Integer no = 100;
//        
//        String s = String.valueOf(55);
//        
        
        if(args.length > 0){
        
            Arithmetic armtc = new Arithmetic();
            
            
            int a = Integer.parseInt( args[0]);
            int b = Integer.parseInt( args[2]);
            char op = args[1].charAt(0);
            
            armtc.getValue(a, b, op);
            
        }else{
        
            System.out.println("Please Enter Three Parameter Like op1 opent op2");
            
        }
        
        
    }
    
    
}

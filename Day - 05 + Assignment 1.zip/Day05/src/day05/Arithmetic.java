/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package day05;

/**
 *
 * @author macstudent
 */
public class Arithmetic {
    
    
    public void getValue(int a, int b, char op){
    
        
        
        switch(op){
        
            case '+' : 
            
                System.out.println("Addition Is : " + (a+b));
                break;
            
            case '*' : 
                System.out.println("Multiplication Is : " + (a*b));
                break;
                
            case '/' : 
                System.out.println("Division Is : " + ((double)a / (double)b));
                break;
                
            case '-' : 
                System.out.println("Subtraction is : " + (a-b));
                break;
                
                default: System.out.println("Thank you");
                        break;
            
        }
        
    }
    
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment1;

import java.util.Arrays;

/**
 *
 * @author macstudent
 */
public class Security {
    
    
    
    public static void main(String[] args) {
        
        
        
        Security sc = new Security();
        
        sc.Encript("My Name Is Nirav Bavishi", "NBLP");
        
    }
    
    
    
    public void Encript(String msg, String key){
    
        char[] tempkey;
        tempkey = key.toCharArray();
        
     
        
        
        int Rows = (msg.length()/key.length())+2;
        
        char[][] StorArray = new char[Rows][key.length()];
        
        
        
        StringBuilder finalData = new StringBuilder();
                
        
        int i=0, j=0;
        
//        for(int i=0; i<Rows; i++){
//        
//            for(int j=0; j<key.length(); j++){
//            
//                if(tempkey[j] != null){
//                StorArray[i][j] = tempkey[j];
//                }
//            }
//            
//        }
        
        for(char c : key.toCharArray()){
        
                StorArray[i][j] = c;
                j++;
            
            if(j >= key.length()){
            
                i++;
                j=0;
                
            }
        }
        
        for(char cd : msg.toCharArray()){
        
                StorArray[i][j] = cd;
                j++;
            
            if(j >= key.length()){
            
                i++;
                j=0;
                
            }
        }
        
        
        Arrays.sort(tempkey);
           
           System.out.println("Sorted Key : " + Arrays.toString(tempkey));
           
           for(int x=0; x < key.length(); x++ ){
           
               for (int l = 0; l < key.length(); l++) {


                    if(tempkey[x] == StorArray[0][l]){

                        for (int k = 0; k < Rows; k++) {

                            finalData.append(StorArray[k][l]);

                         }

                    } 
               }   
           }
    
        // Print
        
        System.out.println("Final Array : " + finalData.toString());
        
           for(int x=0; x<Rows; x++){
        
            for(int y=0; y<key.length(); y++){
            
                System.out.print(StorArray[x][y]);
                
            }
               System.out.println("");
            
        }
           
           
    //// Print
    
    
    Security cs = new Security();
            
            cs.Decript(finalData.toString(), key);
    
    }
    
    
    public void Decript(String msg, String key){
         
          char[] tempkey;
        tempkey = key.toCharArray();
        
        
        
        char[] tempstr;
        tempstr = msg.toCharArray();
        
        int Rows = (msg.length()/key.length());
        
         char[][] StorArray = new char[Rows][key.length()];
         
         char[][] TempArray = new char[Rows][key.length()];
        
        StringBuilder finalData = new StringBuilder();
                
        
        int i=0, j=0;
        
        
            for(char cd : msg.toCharArray()){
        
                StorArray[i][j] = cd;
                i++;
            
            if(i >= Rows){
            
                j++;
                i=0;
                
            }
        }
            
               for(int x=0; x < key.length(); x++ ){
           
               for (int l = 0; l < key.length(); l++) {


                    if(tempkey[x] == StorArray[0][l]){

                        for (int k = 0; k < Rows; k++) {

                           
                            
                            TempArray[k][x] = StorArray[k][l];
                            

                         }

                    } 
               }   
           }
        
            
            
              // Print
        
       // System.out.println("Final Array : " + finalData.toString());
       
       System.out.println("------------- Decription -------------");
       
           for(int x=0; x<Rows; x++){
        
            for(int y=0; y<key.length(); y++){
            
                System.out.print(StorArray[x][y]);
                
            }
               System.out.println("");
            
        }
           
           System.out.println("Temp Array");
            for(int x=1; x<Rows; x++){
        
            for(int y=0; y<key.length(); y++){
            
                System.out.print(TempArray[x][y]);
                 finalData.append(TempArray[x][y]);
                
            }
               System.out.println("");
            
        }
       System.out.println("//------------- Decription -------------");    
         System.out.println("Final Message is : " + finalData.toString().trim());  
    //// Print
            
           }
    
         
    
    
}

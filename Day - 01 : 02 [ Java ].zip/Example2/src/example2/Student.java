/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package example2;

/**
 *
 * @author macstudent
 */
public class Student {
    
    int studentId;
    String name;
    int[] marks;
    float total;
    double percentage;
    String result;
    
    Student(){
    
        this.studentId = 0;
        this.name = null;
        this.marks = new int[5];
        this.total = 0.0f;
        
    }
    
    Student(int studentId, String name, int[] marks){
    
        this.studentId = studentId;
        this.name = name;
        this.marks = marks;
        this.total = 0;
         for(int i=0; i<marks.length; i++){
        
           this.total += marks[i];
            
        }
      
        
    }
    
    
    void printStudentDetails(){
    
        System.out.println("Student Id : " + studentId);
        System.out.println("Student Name : " + name);
        
         System.out.println("-------------------------------------------");
        
        for(int i=0; i<marks.length; i++){
        
            System.out.println("Subject "+(i + 1)+ " : " + marks[i]);
            
        }
        
        System.out.println("-------------------------------------------");
        System.out.println("Total Marks : " + total);
        System.out.println("Percentage : " + percentage);
        System.out.println("Result : " + result);
        
    }
    
    
    
    
    
    
    void calculateResult(){
    
        int ResultFlag = 0;
        
            for(int i=0; i<marks.length; i++){

          if(marks[i] < 40){

              ResultFlag ++;
          }
        
        }
            
            if(ResultFlag >= 2){
            
                double temp = total/500;
                
                percentage = temp*100;
                
                if (percentage > 85){
                
                   result = "A";
                    
                } else if (percentage > 75 && percentage < 85) {
                    
                    result = "B";
                    
                } else if (percentage > 65 && percentage < 75) {
                    
                    result = "C";
                    
                } else if (percentage > 55 && percentage < 65) {
                    
                    result = "D";
                    
                }
                
            } else {
            
                percentage = 0;
                result = "Fail";
            }
            
    }
    
    
    public static void main(String[] args) {
        
        
        Student s1 = new Student(0, "Nirav Bavishi", new int[]{80,80,80,80,80});
        
        s1.printStudentDetails();
        
    }
    
}

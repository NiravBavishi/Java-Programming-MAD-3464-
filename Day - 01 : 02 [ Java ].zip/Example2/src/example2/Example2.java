/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package example2;

/**
 *
 * @author macstudent
 */
public class Example2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        int a = 0, f=10;
        float b = 10.5F;
        long c = 100;
        double d = 100.0;
//        String name = new String ("Hello Nirav");
        String name = "Hello Nirav";
        
        System.out.println("A : " + a);
        System.out.println("b : " + b);
        System.out.println("c : " + c);
        System.out.println("d : " + d);
        System.out.println("Name : " + name);
        
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package example2;

/**
 *
 * @author macstudent
 */
public class Valuetest {
    
    
      public static void main(String[] args) {
        // TODO code application logic here
        
        int a1 = 10, a2=10;
     
        
        System.out.println("A1 : " + a1);
        System.out.println("A2 : " + a2);
        
        
        String s1 = "Hello";
        String s2 = "Hello";
        String s3 = new String("Hello");
        
        System.out.println("s1 : " + s1);
        System.out.println("s2 : " + s2);
        System.out.println("s3 : " + s3);
        
        
          String s4 = s3;
          System.out.println("s4 before : " + s4);
          
          s3 = "Welcome";
          
          System.out.println("s4 After Change : " + s4);
                  
                  
          s4 = "Hello Word";
          System.out.println("s4 : " + s4);
          
          
          
        System.out.println("Number Of A :" + countString('a'));
         System.out.println("Number Of E :" + countString1('e'));
        
       
        
        
    }
      
      
      
      public static int countString(char str){
      
          String sent = "Welcome To Lambton College";
          
          int counter = 0;
          
          char[] strng = sent.toCharArray();
          
         for (int i=0; i<sent.length(); i++){
         
             if (strng[i] == str){
             
                 counter ++;
                 
             }
             
             
         }
          
          return counter;
          
      }
      
       public static int countString1(char str){
      
          String sent = "Welcome To Lambton College";
          
          int counter = 0;
          
         
          
         for (int i=0; i<sent.length(); i++){
         
             if (sent.charAt(i) == str){
             
                 counter ++;
                 
             }
             
             
         }
          
          return counter;
          
      }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package example2;

import java.text.DecimalFormat;

/**
 *
 * @author macstudent
 */
public class Stdnt {
    
    
        int studentId;
    String name;
    int[] marks;
    float total;
    double percentage;
    String result;
    
    Stdnt(){
    
        this.studentId = 0;
        this.name = null;
        this.marks = new int[5];
        this.total = 0.0f;
        
    }
    
    Stdnt(int studentId, String name, int[] marks){
    
        this.studentId = studentId;
        this.name = name;
        this.marks = marks;
        this.total = 0;
         for(int i=0; i<marks.length; i++){
        
           this.total += marks[i];
            
        }
      
        
    }
    
    
    void printStudentDetails(){
    
        System.out.println("Student Id : " + studentId);
        System.out.println("Student Name : " + name);
        
         System.out.println("-------------------------------------------");
        
        for(int i=0; i<marks.length; i++){
        
            System.out.println("Subject "+(i + 1)+ " : " + marks[i]);
            
        }
        
        System.out.println("-------------------------------------------");
        System.out.println("Total Marks : " + total);
        System.out.println("Percentage : " +  customFormat("00.00", percentage));
        System.out.println("Result : " + result);
        
    }
    
    
     public String customFormat(String pattern, double value ) {
      DecimalFormat myFormatter = new DecimalFormat(pattern);
      String output = myFormatter.format(value);
      
      
      return output;
   }
    
    
    
    void calculateResult(){
    
        int ResultFlag = 0;
        
            for(int i=0; i<marks.length; i++){

          if(marks[i] > 40){

              ResultFlag ++;
          }
       
        }
            
            if(ResultFlag >= 2){
            
                double temp = total/500;
                
                percentage = temp*100;
                
                
                
                if (percentage > 85){
                
                   result = "A";
                    
                } else if (percentage > 75 && percentage < 85) {
                    
                    result = "B";
                    
                } else if (percentage > 65 && percentage < 75) {
                    
                    result = "C";
                    
                } else if (percentage > 55 && percentage < 65) {
                    
                    result = "D";
                    
                }
                
            } else {
            
                percentage = 0;
                result = "Fail";
            }
            
    }
    
    
    public static void main(String[] args) {
        
        
        Stdnt s1 = new Stdnt(0, "Nirav Bavishi", new int[]{80,80,80,80,80});
        
        s1.calculateResult();
        s1.printStudentDetails();
        
    }
    
    
}

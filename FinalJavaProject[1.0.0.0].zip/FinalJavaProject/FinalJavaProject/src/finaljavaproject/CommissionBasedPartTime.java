/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finaljavaproject;

/**
 *
 * @author macstudent
 */
public class CommissionBasedPartTime extends PartTime implements IPrintable{

    private int CommissionAmount;

    public int getCommissionAmount() {
        return CommissionAmount;
    }

    public void setCommissionAmount(int CommissionAmount) {
        this.CommissionAmount = CommissionAmount;
    }

    public CommissionBasedPartTime() {
    
        this.CommissionAmount = 0;
        
    }

    public CommissionBasedPartTime(int CommissionAmount) {
        this.CommissionAmount = CommissionAmount;
    }

    public CommissionBasedPartTime(int CommissionAmount, int hourlyRate, int numberHoursWorked, String name, int age, Vehicle v) {
        super(hourlyRate, numberHoursWorked, name, age, v);
        this.CommissionAmount = CommissionAmount;
    }

    @Override
    public double calcEarnings() {
        return super.calcEarnings() + getCommissionAmount(); //To change body of generated methods, choose Tools | Templates.
    }

    

    @Override
    public String printMyData() {
        return super.printMyData() + "\n - Earnings : " + calcEarnings() + "[ (" + getNumberHoursWorked() + " * " + getHourlyRate() + ") + " + getCommissionAmount() + " ]";
    }
    
    
    
    
    
}

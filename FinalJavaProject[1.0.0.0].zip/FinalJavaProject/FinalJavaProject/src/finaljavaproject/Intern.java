/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finaljavaproject;

/**
 *
 * @author macstudent
 */
public class Intern extends Employee implements IPrintable {

    private String schoolname;

    public String getSchoolname() {
        return schoolname;
    }

    public void setSchoolname(String schoolname) {
        this.schoolname = schoolname;
    }

    public Intern() {

        super();
        this.schoolname = null;

    }

    public Intern(String schoolname, String name, int age, Vehicle v) {
        super(name, age, v);
        this.schoolname = schoolname;
    }

    @Override
    public double calcEarnings() {

        return super.calcEarnings();

    }

    @Override
    public String printMyData() {

        return super.printMyData() + "\nEmployee Is Intern \n - School Name : " + getSchoolname() + "\n - Earnings : " + calcEarnings();

    }

}

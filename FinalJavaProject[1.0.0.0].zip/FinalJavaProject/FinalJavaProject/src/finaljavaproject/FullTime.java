/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finaljavaproject;

/**
 *
 * @author macstudent
 */
public class FullTime extends Employee implements IPrintable{
    
    private int salary, bonus;

    public int getSalary() {
        return salary;
    }

    public void setSalary(int salary) {
        this.salary = salary;
    }

    public int getBonus() {
        return bonus;
    }

    public void setBonus(int bonus) {
        this.bonus = bonus;
    }


    
    
    
    
    public FullTime() {
    
        super();
        
        this.salary = 0;
        this.bonus = 0;
        
    }

    public FullTime(int salary, int bonus, String name, int age, Vehicle v) {
        super(name, age, v);
        this.salary = salary;
        this.bonus = bonus;
    }
    
    
    @Override
    public double calcEarnings(){
        
        return (getSalary() + getBonus());
        
    }
    
    @Override
    public String printMyData() {
        
        return super.printMyData() + "\nEmployee is Fulltime \n - Salary : " + getSalary() + "\n - Bonus : " + getBonus() + "\n - Eranings : " + calcEarnings() + "(" + getSalary() + " + " + getBonus() + ")";
        
    }
    
    
}

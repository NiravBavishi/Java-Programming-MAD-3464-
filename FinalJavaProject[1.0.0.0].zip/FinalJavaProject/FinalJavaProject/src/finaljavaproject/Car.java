/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finaljavaproject;

/**
 *
 * @author Jay Patel
 */
public class Car extends Vehicle implements IPrintable{

    private String color;
    private int cc;

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public int getCc() {
        return cc;
    }

    public void setCc(int cc) {
        this.cc = cc;
    }

    public Car() {
    
    
        this.cc = 0;
        this.color = null;
        
    }

    public Car(String color, int cc) {
        this.color = color;
        this.cc = cc;
    }

    public Car(String color, int cc, String make, String model) {
        super(make, model);
        this.color = color;
        this.cc = cc;
    }

    
    
    
    
    @Override
    public String printMyData() {
        return super.printMyData() + "\n - Color : " + getColor() + "\n - CC : " + getCc();
    }
    
}

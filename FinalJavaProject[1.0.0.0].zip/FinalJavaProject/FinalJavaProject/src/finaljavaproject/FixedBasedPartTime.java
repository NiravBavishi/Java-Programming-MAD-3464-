/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finaljavaproject;

/**
 *
 * @author macstudent
 */
public class FixedBasedPartTime extends PartTime implements IPrintable{

    private int FixedAmount;

    public int getFixedAmount() {
        return FixedAmount;
    }

    public void setFixedAmount(int FixedAmount) {
        this.FixedAmount = FixedAmount;
    }

    public FixedBasedPartTime() {
    
        this.FixedAmount = 0;
        
    }

    public FixedBasedPartTime(int FixedAmount) {
        this.FixedAmount = FixedAmount;
    }

    public FixedBasedPartTime(int FixedAmount, int hourlyRate, int numberHoursWorked, String name, int age, Vehicle v) {
        super(hourlyRate, numberHoursWorked, name, age, v);
        this.FixedAmount = FixedAmount;
    }

    @Override
    public int calcBirthYear() {
        return super.calcBirthYear() + this.FixedAmount; //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String printMyData() {
        return super.printMyData()  + "\n - Earnings : " + calcEarnings() + "[ (" + getNumberHoursWorked() + " * " + getHourlyRate() + ") + " + getFixedAmount() + " ]"; //To change body of generated methods, choose Tools | Templates.
    }
    
    
    
    
    
    
}

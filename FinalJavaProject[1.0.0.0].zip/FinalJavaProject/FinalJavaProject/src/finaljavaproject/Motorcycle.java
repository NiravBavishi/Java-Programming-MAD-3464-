/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finaljavaproject;

/**
 *
 * @author Jay Patel
 */
public class Motorcycle extends Vehicle implements IPrintable{
 
    
    private String engineType;
    private int cc;

    public String getEngineType() {
        return engineType;
    }

    public void setEngineType(String engineType) {
        this.engineType = engineType;
    }

    public int getCc() {
        return cc;
    }

    public void setCc(int cc) {
        this.cc = cc;
    }

    

    public Motorcycle() {
    
        this.cc = 0;
        this.engineType = null;
        
    }

    public Motorcycle(String engineType, int cc) {
        this.engineType = engineType;
        this.cc = cc;
    }

    public Motorcycle(String engineType, int cc, String make, String model) {
        super(make, model);
        this.engineType = engineType;
        this.cc = cc;
    }
    
        @Override
    public String printMyData() {
        return super.printMyData() + "\n - Engine Type : " + getEngineType() + "\n - CC : " + getCc();
    }
    
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finaljavaproject;

import java.util.ArrayList;
import java.util.Calendar;

/**
 *
 * @author macstudent
 */
public class Employee implements IPrintable{
    
    
   private String name;
   private int age;
   private Vehicle v;
   private static ArrayList<Employee> employeeList = new ArrayList<>();

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public Vehicle getV() {
        return v;
    }

    public void setV(Vehicle v) {
        this.v = v;
    }

    public static ArrayList<Employee> getEmployeeList() {
        return employeeList;
    }

    public static void setEmployeeList(ArrayList<Employee> employeeList) {
        Employee.employeeList = employeeList;
    }
    
   
   
   
   

    public Employee() {
    
        this.name = null;
        this.age = 0;
        this.v = null;
        
    }

    public Employee(String name, int age, Vehicle v) {
    
        this.name = name;
        this.age = age;
        this.v = v;
        
    }
    
    
    public int calcBirthYear(){
    
        int year = Calendar.getInstance().get(Calendar.YEAR);
        return (year - this.age);
        
    }
   
    
    public double calcEarnings(){
    
        return 1000.00;
        
    }

    public static void addEmployee(Employee e){
    
        employeeList.add(e);
        
    }
    
    @Override
    public String printMyData() {
        
        
        StringBuilder returnStr = new StringBuilder();
        
        returnStr.append("Name : ").append(this.name).append("\nBirth Year : ").append(calcBirthYear());
        
        Vehicle v = new Vehicle();

            v = this.getV();
            if (v == null) {

                returnStr.append("\nEmployee has No Vehicle");

            } else {

                if (v instanceof Car) {

                    returnStr.append("\nEmployee has Car");

                } else if (v instanceof Motorcycle) {

                    returnStr.append("\nEmployee has Motorcycle");

                }

                returnStr.append(v.printMyData());

            }
        
        
        return returnStr.toString();
    }
    
    
}

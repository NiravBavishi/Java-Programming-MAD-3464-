/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finaljavaproject;

/**
 *
 * @author macstudent
 */
public class Vehicle implements IPrintable{
    
    
    private String make, model;

    public String getMake() {
        return make;
    }

    public void setMake(String make) {
        this.make = make;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }
    
    
    
    public Vehicle(){
    
        this.make = null;
        this.model = null;
        
    }
    
    public Vehicle(String make, String model){
    
        this.make = make;
        this.model = model;
        
    }

    @Override
    public String printMyData() {
        
        return "\n - Make : " + this.make + "\n - Model : " + this.model;
        
    }
    
    
    
    
}

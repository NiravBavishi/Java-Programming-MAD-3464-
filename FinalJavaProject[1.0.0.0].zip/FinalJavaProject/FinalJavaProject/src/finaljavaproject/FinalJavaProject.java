/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finaljavaproject;

import java.util.ArrayList;
import java.util.Calendar;

/**
 *
 * @author macstudent
 */
public class FinalJavaProject {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        double totalPayroll = 0.0;

        Car car1 = new Car("Black", 2000, "Lamborghini", "Terzo");
        Motorcycle mtc1 = new Motorcycle("Vertical", 500, "Ducati", "XDevia");

        FullTime ft1 = new FullTime(100, 250, "Nirav Patel", 22, car1);
        Intern it1 = new Intern("Lambton College", "Hardik Patel", 21, null);
        CommissionBasedPartTime cbpt1 = new CommissionBasedPartTime(75, 12, 20, "Nirav Bavishi", 20, car1);
        FixedBasedPartTime fbpt1 = new FixedBasedPartTime(80, 15, 20, "Indra Shrimali", 25, mtc1);

        Employee.addEmployee(ft1);
        Employee.addEmployee(cbpt1);
        Employee.addEmployee(fbpt1);
        Employee.addEmployee(it1);

        ArrayList<Employee> empList = new ArrayList<>(Employee.getEmployeeList());

        for (Employee e : empList) {

            totalPayroll += e.calcEarnings();

            System.out.println(e.printMyData());

            System.out.println("-----------------------------------------------");
        }

        System.out.println("Total Payroll : " + totalPayroll + " Canadian Dollers");

    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finaljavaproject;

/**
 *
 * @author macstudent
 */
public class PartTime extends Employee implements IPrintable{


    private int hourlyRate, numberHoursWorked;

    public int getHourlyRate() {
        return hourlyRate;
    }

    public void setHourlyRate(int hourlyRate) {
        this.hourlyRate = hourlyRate;
    }

    public int getNumberHoursWorked() {
        return numberHoursWorked;
    }

    public void setNumberHoursWorked(int numberHoursWorked) {
        this.numberHoursWorked = numberHoursWorked;
    }


    
    
    public PartTime() {
    
        super();
        this.hourlyRate = 0;
        this.numberHoursWorked = 0;
        
    }

    public PartTime(int hourlyRate, int numberHoursWorked, String name, int age, Vehicle v) {
        super(name, age, v);
        this.hourlyRate = hourlyRate;
        this.numberHoursWorked = numberHoursWorked;
    }
    
    
    @Override
    public double calcEarnings(){
        
        return (this.numberHoursWorked * this.hourlyRate);
        
    }
    
    @Override
    public String printMyData(){
    
        StringBuilder returnStr = new StringBuilder();
        
        returnStr.append(super.printMyData());
        
        if (this instanceof CommissionBasedPartTime) {
            
            returnStr.append( "\nEmployee is Parttime / Commissioned \n - Rate : ");
            
        }else if (this instanceof FixedBasedPartTime) {
            
            returnStr.append( "\nEmployee is Parttime / FixedBased \n - Rate : ");
            
        }
        
        
        returnStr.append(getHourlyRate()).append("\n - Hour Worked : ").append(getNumberHoursWorked());
        
        return returnStr.toString();
        
        //return super.printMyData() + "\nEmployee is Parttime / Commissioned \n - Rate : " + getHourlyRate() + "\n - Hour Worked : " + getNumberHoursWorked() + "\n - Earnings : " + calcEarnings() + "(" + getNumberHoursWorked() + " * " + getHourlyRate() + ")";
    }

    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package c0717705_midterm_madf3464;

/**
 *
 * @author macstudent
 */
public class C0717705_MidTerm_MADF3464 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        
        MagicalCardGameModel mcg = new MagicalCardGameModel();
        
       
        
        
        
        mcg.displayMatrix();
         int col = mcg.getColumnNo();
        mcg.firstShuffle(col);
        
         col = mcg.getColumnNo();
        
        mcg.secondShuffle(col);
        
        System.out.println("---------------------------------------------");
        
        StringTools st = new StringTools();
        
        st.reverse("Nirav Patel");
        
        st.mostFrequent("My name Is Nirav Bavishi");
        
        st.initials("Nirav Bavishi Patel");
        
        
        
    }
    
}

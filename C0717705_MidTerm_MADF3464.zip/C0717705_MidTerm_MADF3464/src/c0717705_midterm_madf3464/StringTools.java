/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package c0717705_midterm_madf3464;

import java.util.Arrays;

/**
 *
 * @author macstudent
 */
public class StringTools {

    public void reverse(String s) {

        System.out.println("Original String : " + s);

        int Length = 0;

        StringBuilder revsb = new StringBuilder();

        for (char c : s.toCharArray()) {

            Length++;

        }

        char[] rev = s.toCharArray();

        for (int j = Length - 1; j >= 0; j--) {

            revsb.append(rev[j]);

        }

        System.out.println("Reverse  String : " + revsb.toString());

    }

    public void mostFrequent(String s) {

        char str[] = s.toCharArray();

        StringBuilder sbchar = new StringBuilder();
        int charCount = 0;

        sbchar.append(str[0]);

        for (int i = 0; i < str.length; i++) {

            if (str[i] == ' ') {

                for (int j = i + 1; j < str.length; j++) {

                    str[i] = str[j];

                }
            }

        }

        for (int i = 0; i < str.length; i++) {

            for (int j = 0; j < sbchar.length(); j++) {

                if (sbchar.charAt(j) == str[i]) {

                    charCount++;

                }

            }

            if (charCount > 0) {

                sbchar.append(str[i]);

            }

        }

        int[] count = new int[sbchar.length()];

        for (int i = 0; i < sbchar.length(); i++) {

            count[i] = 0;

        }

        for (int i = 0; i < sbchar.length(); i++) {

            for (int j = 0; j < str.length; j++) {

                if (sbchar.charAt(i) == str[j]) {

                    count[i]++;

                }

            }

        }

        int index = 0;

        for (int i = 1; i < count.length; i++) {

            if (count[0] < count[i]) {
                count[0] = count[i];
                index = i;

            }

        }

        System.out.println("Most Frequent Word is : " + sbchar.charAt(index));

    }

    public void initials(String s) {

        char[] str;
        str = s.toCharArray();
        int count = 1;

        StringBuilder namesb = new StringBuilder(s);

        int CoutSpace = 0;

        for (int i = 0; i < str.length; i++) {

            if (str[i] == ' ') {

                CoutSpace++;
            }

        }

        if (CoutSpace > 0) {

            CoutSpace = 0;

            for (int i = 1; i < str.length; i++) {

                if (namesb.charAt(i) != ' ') {
//                    System.out.println(namesb.toString());
//                    System.out.println(namesb.charAt(i));
//                    System.out.println(i);
                    namesb.deleteCharAt(i);
                    i--;

                } else {
                    namesb.setCharAt(i, '.');
                    i++;
                    CoutSpace++;
                    if (CoutSpace > 1) {

                        break;
                    }

                }

            }

            System.out.println("Name Is : " + namesb.toString());

        } else {

            System.out.println("Please Enter Valid Number");

        }

    }

    public void replaceSubString(String s1, String s2, String s3) {

        StringBuilder strsb;
        strsb = new StringBuilder(s1);
        
        StringBuilder str1sb;
        str1sb = new StringBuilder(s2);
        
        int tempCounter = 0;
        
        
        for (int i = 0; i < strsb.length(); i++) {

            if(strsb.charAt(i) == str1sb.charAt(0)){
            
                for (int j = 0; j < str1sb.length(); j++) {

                    if(strsb.charAt(i+j) == str1sb.charAt(j)){
                    
                        tempCounter ++;
                        
                    }
                    
                }
                
                if(tempCounter >= 3){
                
                    
                    
                }
                
            }
            
        }

    }

  

}

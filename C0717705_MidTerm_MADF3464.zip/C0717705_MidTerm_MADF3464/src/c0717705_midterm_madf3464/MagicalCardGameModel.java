/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package c0717705_midterm_madf3464;

import java.util.Scanner;

/**
 *
 * @author macstudent
 */
public class MagicalCardGameModel {

    String firstShuffleColPos;
    String secShuffleColPos;
    String[][] cardList = {{"1", "A", "5"}, {"2", "7", "3"}, {"3", "6", "K"}};
    String[][] firstShuffle = new String[3][3];
    String[][] secShuffle = new String[3][3];
    String guessedCard;

    public String getFirstShuffleColPos() {
        return firstShuffleColPos;
    }

    public void setFirstShuffleColPos(String firstShuffleColPos) {
        this.firstShuffleColPos = firstShuffleColPos;
    }

    public String getSecShuffleColPos() {
        return secShuffleColPos;
    }

    public void setSecShuffleColPos(String secShuffleColPos) {
        this.secShuffleColPos = secShuffleColPos;
    }

    public String[][] getCardList() {
        return cardList;
    }

    public void setCardList(String[][] cardList) {
        this.cardList = cardList;
    }

    public String[][] getFirstShuffle() {
        return firstShuffle;
    }

    public void setFirstShuffle(String[][] firstShuffle) {
        this.firstShuffle = firstShuffle;
    }

    public String[][] getSecShuffle() {
        return secShuffle;
    }

    public void setSecShuffle(String[][] secShuffle) {
        this.secShuffle = secShuffle;
    }

    public String getGuessedCard() {
        return guessedCard;
    }

    public void setGuessedCard(String guessedCard) {
        this.guessedCard = guessedCard;
    }

    public int getColumnNo() {

        Scanner reader = new Scanner(System.in);

        System.out.println(
                "What Is The Column Number : ");
        int n = reader.nextInt();
       // reader.close();

        return n;

    }

    public void displayMatrix() {

        System.out.println("-------------------- Original Matrix ---------------------");
        
        for (int i = 0; i < 3; i++) {

            for (int j = 0; j < 3; j++) {

                System.out.print(cardList[i][j] + " ");

            }
            System.out.println("");

        }
        
        System.out.println("Please Choose Your Card. . .");

    }

    public void firstShuffle(int ColumnNo) {

        int ChoosedCol = 0;

        switch (ColumnNo) {

            case 1:

                for (int i = 0; i < 3; i++) {

                    if (i == 0) {
                        ChoosedCol = 1;
                    }
                    if (i == 1) {
                        ChoosedCol = 0;
                    }

                    if (i == 2) {
                        ChoosedCol = 2;
                    }

                    for (int j = 0; j < 3; j++) {

                        firstShuffle[i][j] = cardList[j][ChoosedCol];

                    }

                }

                break;

            case 2:

                for (int i = 0; i < 3; i++) {

                    for (int j = 0; j < 3; j++) {

                        firstShuffle[i][j] = cardList[j][i];

                    }

                }

                break;

            case 3:

                for (int i = 0; i < 3; i++) {

                    if (i == 0) {
                        ChoosedCol = 1;
                    }
                    if (i == 1) {
                        ChoosedCol = 2;
                    }

                    if (i == 2) {
                        ChoosedCol = 0;
                    }

                    for (int j = 0; j < 3; j++) {

                        firstShuffle[i][j] = cardList[j][ChoosedCol];

                    }

                }

                break;
                
                default: System.out.println("Please Select Correct Column Number");
                break;
        }

        
                System.out.println("-------------------- After First Shuffle Matrix ---------------------");
        for (int i = 0; i < 3; i++) {

            for (int j = 0; j < 3; j++) {

                System.out.print(firstShuffle[i][j] + " ");

            }
            System.out.println("");

        }
        
    }

    
    
    
    public void secondShuffle(int ColumnNo) {

        int ChoosedCol = 0;

        switch (ColumnNo) {

            case 1:

                for (int i = 0; i < 3; i++) {

                    if (i == 0) {
                        ChoosedCol = 1;
                    }
                    if (i == 1) {
                        ChoosedCol = 0;
                    }

                    if (i == 2) {
                        ChoosedCol = 2;
                    }

                    for (int j = 0; j < 3; j++) {

                        secShuffle[i][j] = firstShuffle[j][ChoosedCol];

                    }

                }

                break;

            case 2:

                for (int i = 0; i < 3; i++) {

                    for (int j = 0; j < 3; j++) {

                        secShuffle[i][j] = firstShuffle[j][i];

                    }

                }

                break;

            case 3:

                for (int i = 0; i < 3; i++) {

                    if (i == 0) {
                        ChoosedCol = 1;
                    }
                    if (i == 1) {
                        ChoosedCol = 2;
                    }

                    if (i == 2) {
                        ChoosedCol = 0;
                    }

                    for (int j = 0; j < 3; j++) {

                        secShuffle[i][j] = firstShuffle[j][ChoosedCol];

                    }

                }

                break;
                
                default: System.out.println("Please Select Correct Column Number");
                break;
        }

        
                System.out.println("-------------------- After Second Shuffle Matrix ---------------------");
        for (int i = 0; i < 3; i++) {

            for (int j = 0; j < 3; j++) {

                System.out.print(secShuffle[i][j] + " ");

            }
            System.out.println("");

        }
        
        
        System.out.println("Your card Is : " + secShuffle[1][1]);
        
    }
    
    
    
    
    
}

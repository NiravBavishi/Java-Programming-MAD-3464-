/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package userdefinefunctions;

/**
 *
 * @author macstudent
 */
public class Security {
    
    
    
    public static void main(String[] args) {
        
        
        
        Security sc = new Security();
        
        sc.Encript("My Name Is Nirav Bavishi", "NBLP");
        
    }
    
    public void Encript(String str, String key){
    
        char[] tempkey;
        tempkey = key.toCharArray();
        
        char[] tempstr;
        tempstr = str.toCharArray();
        
        int Rows = (str.length()/key.length())+2;
        
        char[][] StorArray = new char[Rows][key.length()];
        
        int i=0, j=0;
        
//        for(int i=0; i<Rows; i++){
//        
//            for(int j=0; j<key.length(); j++){
//            
//                if(tempkey[j] != null){
//                StorArray[i][j] = tempkey[j];
//                }
//            }
//            
//        }
        
        for(char c : key.toCharArray()){
        
                StorArray[i][j] = c;
                j++;
            
            if(j >= key.length()){
            
                i++;
                j=0;
                
            }
        }
        
        for(char cd : str.toCharArray()){
        
                StorArray[i][j] = cd;
                j++;
            
            if(j >= key.length()){
            
                i++;
                j=0;
                
            }
        }
        
    
           for(int x=0; x<Rows; x++){
        
            for(int y=0; y<key.length(); y++){
            
                System.out.print(StorArray[x][y]);
                
            }
               System.out.println("");
            
        }
    
    
    }
    
    
         
    
    
}

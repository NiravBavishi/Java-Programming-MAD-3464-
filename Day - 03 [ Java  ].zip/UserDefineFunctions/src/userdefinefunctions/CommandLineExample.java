/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package userdefinefunctions;

/**
 *
 * @author macstudent
 */
public class CommandLineExample {
    
    
    public static void main(String[] args) {
        
        
        System.out.println("Welcome To Command Line Argument");
        System.out.println("Number Of Argument : " + args.length);
       System.out.println("Number["+ args[0] + "] Of Argument : " + args[0]);
       System.out.println("Number["+ args[6] + "] Of Argument : " + args[6]);
       
        System.out.println("");
        
        
        
    }
    
    
}

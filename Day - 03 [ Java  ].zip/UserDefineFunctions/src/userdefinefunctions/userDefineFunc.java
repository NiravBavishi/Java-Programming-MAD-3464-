/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package userdefinefunctions;

import java.util.Arrays;

/**
 *
 * @author macstudent
 */
public class userDefineFunc {
    
    
    UserDefineFunctions sd = new UserDefineFunctions();
    
    
     {
        System.out.println("HEllo Indumati. . . 1");
    }
    
    
    public void sumOfNmbers(int no){
    
        int TempNo = 0;
        
        for(int i=0; i<no; i++){
        
            TempNo += i;
            
        }
        
        System.out.println("Total Is : "+ TempNo);
        
    }
    
    
    public void reverseString(String str){
    
    
        StringBuilder Reverse = new StringBuilder();
        
        
        
        for(int i=str.length()-1; i >= 0; i--){
        
            Reverse.append(str.charAt(i));
        
        }
        
       System.out.println("Reverse String Is : " + Reverse.toString());
        
    }
    
    public void min(int no1, int no2, int no3){
    
    
        if (no1 < no2 && no1 < no3){
        
            System.out.println(no1 + " Is Minimum");
            
        }
        else {
        
            if(no2 < no3){
            
                System.out.println(no2 + " Is Minimum");
                
            }
            else{System.out.println(no3 + " Is Minimum");}
            
        }
        
    }
    
    public void max(int no1, int no2, int no3){
    
    
        if (no1 > no2 && no1 > no3){
        
            System.out.println(no1 + " Is Maximum");
            
        }
        else {
        
            if(no2 > no3){
            
                System.out.println(no2 + " Is Maximum");
                
            }
            else{System.out.println(no3 + " Is Maximum");}
            
        }
        
    }
    
    
    public void Names(String[] name){
    
        StringBuilder NamesString = new StringBuilder();
        
        for(int i=0; i< name.length; i++){
        
            NamesString.append(name[i]);
            
        }
        
        System.out.println("One String : " + NamesString.toString());
        
    }
    
    
    public void Names2(String[] name){
    
        StringBuilder NamesString = new StringBuilder();
        
        for(String Temps : name){
        
            NamesString.append(Temps);
            
        }
        
        System.out.println("One String : " + NamesString.toString());
        
    }
    
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package userdefinefunctions;

/**
 *
 * @author macstudent
 */
public class ReverseOfReverse {
    
    public static void main(String[] args) {
        
        StringBuilder sb = new StringBuilder();
        StringBuilder tempStr = new StringBuilder();
        
        
        for(int i=0; i<args.length; i++){
        
            tempStr.setLength(0);
            
            tempStr.append(args[i]);
            tempStr.reverse();
            sb.append(tempStr);
            
        }
        
        System.out.println("Reverse Of Reverse Is >> " + sb.reverse().toString());
        
        
    }
    
    
    
    
}

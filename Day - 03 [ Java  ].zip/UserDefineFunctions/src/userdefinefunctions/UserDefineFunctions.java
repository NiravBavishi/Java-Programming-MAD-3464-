/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package userdefinefunctions;

/**
 *
 * @author macstudent
 */
public class UserDefineFunctions {

    /**
     * @param args the command line arguments
     */
    
    {
        System.out.println("HEllo Indumati. . .");
    }
    public static void main(String[] args) {
        // TODO code application logic here
        
        
        userDefineFunc obj = new userDefineFunc();
        
        obj.sumOfNmbers(7);
        obj.reverseString("Nirav Bavishi");
        obj.min(7, 28, 33);
        obj.max(28,33,7);
        obj.Names(new String[]{"Name1 ","Name 2"});
        obj.Names2(new String[]{"Name1 ","Name 2 ", "Name 3"});
        
    }
    
}
